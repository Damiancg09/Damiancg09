<?php

namespace ScoreboardStats;

use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class ScoreboardManager {

    private $plugin;

    public function __construct($plugin) {
        $this->plugin = $plugin;
    }

    public function createScoreboard(Player $player): void {
        $player->sendTip(TF::YELLOW . "Bienvenido al servidor, " . $player->getName());
    }

    public function updateScoreboard(Player $player, int $kills, int $balance): void {
        $scoreboard = [
            TF::BOLD . TF::GREEN . "=== Stats ===",
            TF::AQUA . "Kills: " . TF::WHITE . $kills,
            TF::AQUA . "Dinero: $" . TF::WHITE . $balance,
            TF::BOLD . TF::GREEN . "=============="
        ];

        $player->sendPopup(implode("\n", $scoreboard));
    }
}