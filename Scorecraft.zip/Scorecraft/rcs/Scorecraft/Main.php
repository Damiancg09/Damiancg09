<?php

namespace ScoreboardStats;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\utils\TextFormat as TF;
use cooldogedev\BedrockEconomy\api\BedrockEconomyAPI;
use ScoreboardStats\ScoreboardManager;

class Main extends PluginBase implements Listener {

    private ScoreboardManager $scoreboardManager;

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->scoreboardManager = new ScoreboardManager($this);

        if ($this->getServer()->getPluginManager()->getPlugin("BedrockEconomy") === null) {
            $this->getLogger()->error("BedrockEconomy no está instalado. Deshabilitando ScoreboardStats...");
            $this->getServer()->getPluginManager()->disablePlugin($this);
        }
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $this->scoreboardManager->createScoreboard($player);
        $this->updateScoreboard($player);
    }

    public function onDeath(PlayerDeathEvent $event): void {
        $player = $event->getEntity();
        if ($player instanceof Player) {
            $this->updateScoreboard($player);
        }
    }

    public function updateScoreboard(Player $player): void {
        $kills = $player->getStats()->getDeathCount(); // Cambia según cómo quieras contar los kills

        BedrockEconomyAPI::getInstance()->getPlayerBalance($player->getName(), function (int $balance) use ($player, $kills) {
            $this->scoreboardManager->updateScoreboard($player, $kills, $balance);
        });
    }
}